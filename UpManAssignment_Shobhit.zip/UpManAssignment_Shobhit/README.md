# UpMan

# Simple Project to validate is created using Python

1. Here we have 3 python file and one json file of the RCB team.
2. In 'main' file we have called the methods.
3. In 'Players.py' file we have created the method which we are calling from the main.py file.
4. In Constant.py file we have all the Constants added into it.

